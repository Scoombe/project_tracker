import time
"""
function to track change dates and why they occured
"""
def main():
    author  = input("Enter the author of the change: ")
    description = input("Enter the description of the change: ")
    #name of the file changed
    file = input("Enter the file that has been changed: ")
    #getting the time
    date= time.strftime('%d/%m/%y')
    changeFile = open("changes.txt",'a')
    changeString = "====================================\n"\
                    "File changed: " + file + "\n"\
                    "Author of the change: " + author + "\n"\
                    "Description of the change: "+ description + "\n"\
                    "Date of the change: "+date + "\n"
    changeFile.write(changeString)

main()