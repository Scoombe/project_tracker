from setuptools import setup

setup(
    name="project_startup",
    author="sam coombe",
    py_modules=['start_project', 'commit_change'],
)